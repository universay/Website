<!DOCTYPE html><html lang="en" class=""><head><meta charSet="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/><title>Not Found</title><meta name="robots" content="index,follow"/><meta name="googlebot" content="index,follow"/><meta name="twitter:card" content="summary_large_image"/><meta property="og:type" content="website"/><meta property="og:image" content=""/><meta property="og:locale" content="en_US"/><meta name="next-head-count" content="9"/><link rel="preload" href="https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-regular.woff2" crossorigin="anonymous" as="font" type="font/woff2"/><link rel="preload" href="https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-500.woff2" crossorigin="anonymous" as="font" type="font/woff2"/><link rel="preload" href="https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-600.woff2" crossorigin="anonymous" as="font" type="font/woff2"/><link rel="preload" href="https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-700.woff2" crossorigin="anonymous" as="font" type="font/woff2"/><link rel="preload" href="/_next/static/css/4ee25eeda1cb3ee6.css" as="style"/><link rel="stylesheet" href="/_next/static/css/4ee25eeda1cb3ee6.css" data-n-g=""/><noscript data-n-css=""></noscript><script defer="" nomodule="" src="/_next/static/chunks/polyfills-c67a75d1b6f99dc8.js"></script><script defer="" src="/_next/static/chunks/1824.a01cad2a8d34cd1c.js"></script><script src="/_next/static/chunks/webpack-ed208b8861cf19d1.js" defer=""></script><script src="/_next/static/chunks/framework-a070cbfff3c750c5.js" defer=""></script><script src="/_next/static/chunks/main-9d719499c0227aa5.js" defer=""></script><script src="/_next/static/chunks/pages/_app-bbeb797fbd722fc4.js" defer=""></script><script src="/_next/static/chunks/7628-86e9abdae0ae4ec3.js" defer=""></script><script src="/_next/static/chunks/pages/404-d92963ae2ffbf1ff.js" defer=""></script><script src="/_next/static/rIxg8tuj6jbVrseXiNqs0/_buildManifest.js" defer=""></script><script src="/_next/static/rIxg8tuj6jbVrseXiNqs0/_ssgManifest.js" defer=""></script><style id="__jsx-ffddb87d302206e5">body{background-color:#eff4fe!important}.error-wrapper{min-height:100vh;height:100%;width:100%;display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-moz-box-orient:vertical;-moz-box-direction:normal;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:center;-webkit-justify-content:center;-moz-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;text-align:center}.error-not-found{cursor:pointer}.error-image{width:400px;height:327px;position:relative}.error-text{font-size:26px;font-weight:600;line-height:1.8;color:#000}@media(max-width:680px){.error-image{width:500px;height:409px}.error-text{font-size:24px}}@media(max-width:546px){.error-image{width:400px;height:327px}.error-text{font-size:18px}}</style><style id="__jsx-300370251">:root{--color-text-default:rgb(55, 53, 47);--color-text-default-light:rgba(55, 53, 47, 0.6);--color-text-gray:rgb(155, 154, 151);--color-text-brown:rgb(100, 71, 58);--color-text-orange:rgb(217, 115, 13);--color-text-yellow:rgb(223, 171, 1);--color-text-green:rgb(15, 123, 108);--color-text-blue:rgb(11, 110, 153);--color-text-purple:rgb(105, 64, 165);--color-text-pink:rgb(173, 26, 114);--color-text-red:rgb(224, 62, 62);--color-bg-default:rgb(255, 255, 255);--color-bg-gray:rgb(235, 236, 237);--color-bg-brown:rgb(233, 229, 227);--color-bg-orange:rgb(250, 235, 221);--color-bg-yellow:rgb(251, 243, 219);--color-bg-green:rgb(221, 237, 234);--color-bg-blue:rgb(221, 235, 241);--color-bg-purple:rgb(234, 228, 242);--color-bg-pink:rgb(244, 223, 235);--color-bg-red:rgb(251, 228, 228);--color-bg-gray-light:rgba(235, 236, 237, 0.3);--color-bg-brown-light:rgba(233, 229, 227, 0.3);--color-bg-orange-light:rgba(250, 235, 221, 0.3);--color-bg-yellow-light:rgba(251, 243, 219, 0.3);--color-bg-green-light:rgba(221, 237, 234, 0.3);--color-bg-blue-light:rgba(221, 235, 241, 0.3);--color-bg-purple-light:rgba(234, 228, 242, 0.3);--color-bg-pink-light:rgba(244, 223, 235, 0.3);--color-bg-red-light:rgba(251, 228, 228, 0.3);--color-pill-default:rgba(206, 205, 202, 0.5);--color-pill-gray:rgba(155, 154, 151, 0.4);--color-pill-brown:rgba(140, 46, 0, 0.2);--color-pill-orange:rgba(245, 93, 0, 0.2);--color-pill-yellow:rgba(233, 168, 0, 0.2);--color-pill-green:rgba(0, 135, 107, 0.2);--color-pill-blue:rgba(0, 120, 223, 0.2);--color-pill-purple:rgba(103, 36, 222, 0.2);--color-pill-pink:rgba(221, 0, 129, 0.2);--color-pill-red:rgba(255, 0, 26, 0.2);--color-ui-hover-bg:rgba(239, 239, 239);--color-card-bg:rgb(255, 255, 255);--color-checkbox-bg:rgb(46, 170, 220);;--color-border-default:rgba(235, 236, 237, 0.8);--color-border-dark:rgba(55, 53, 47, 0.16);--color-code-bg:rgba(239, 239, 239);--scrollbar-background-color:#fafafa;--scrollbar-thumb-color:#c1c1c1;--scrollbar-border-color:#e8e8e8;--navbar-text-color:var(--color-text-default);--navbar-background-color:var(--color-bg-default);--navbar-button-text-color:var(--color-text-default);--navbar-button-background-color:var(--color-bg-default);--navbar-menu-background-color:var(--navbar-background-color);--footer-text-color:var(--color-text-default);--footer-background-color:var(--color-bg-default);--color-calendar-weekend-bg:#f7f6f3}</style><style id="__jsx-988057495">:root{--padding-layout:0.6rem;--border-radii-layout:5px;--border-thickness-layout:1px;--border-type-layout:solid;--border-layout:var(--border-thickness-layout)
          var(--border-type-layout) var(--color-border-default);--layout-max-width:900px;--column-spacing:46px;--page-display:unset;--padding-right:calc(env(safe-area-inset-right) + 96px);--padding-left:calc(env(safe-area-inset-left) + 96px);--padding-right-mobile:calc(env(safe-area-inset-right) + 24px);--padding-left-mobile:calc(env(safe-area-inset-left) + 24px);--header-cover-height:30vh;--header-title-align:left;--header-icon-align:-112px auto auto auto;--header-display:block;--collection-header-border:var(--border-layout);--collection-table-cell-padding:calc(var(--padding-layout) - 0.3rem)
          calc(var(--padding-layout) - 0.1rem);--collection-list-item-padding:calc(var(--padding-layout) - 0.5rem);--collection-list-item-border-radii:calc(
          var(--border-radii-layout) - 1px
        );--collection-card-padding:0px;--collection-card-title-padding:0px;--collection-card-content-padding:var(--padding-layout);--collection-card-border-radii:var(--border-radii-layout);--collection-card-gap:16px;--collection-card-shadow:rgba(15, 15, 15, 0.1) 0px 0px 0px 1px, rgba(15, 15, 15, 0.1) 0px 2px 4px;--collection-card-title-size:0.875rem;--collection-card-cover-height-small:128px;--collection-card-cover-size-small:172px;--collection-card-cover-height-medium:200px;--collection-card-cover-size-medium:260px;--collection-card-cover-height-large:200px;--collection-card-cover-size-large:320px;--collection-card-icon-display:inline-flex;--callout-padding:calc(var(--padding-layout) + 0.4rem)
          calc(var(--padding-layout) + 0.4rem)
          calc(var(--padding-layout) + 0.4rem)
          calc(var(--padding-layout) + 0.1em);--callout-border-radii:calc(var(--border-radii-layout) - 2px);--callout-border:var(--border-layout);--callout-icon-display:block;--callout-shadow:none;--file-border-radii:calc(var(--border-radii-layout) - 2px);--equation-border-radii:calc(var(--border-radii-layout) - 2px);--divider-border:var(--border-layout);--quote-border:calc(var(--border-thickness-layout) + 2px) solid
          currentcolor;--code-padding:calc(var(--padding-layout) + 1.4rem);--code-border-radii:var(--border-radii-layout);--tweet-padding:calc(var(--padding-layout) + 0.65rem)
          calc(var(--padding-layout) + 0.65rem)
          calc(var(--padding-layout) + 0.05rem)
          calc(var(--padding-layout) + 0.65rem);--tweet-border-radii:var(--border-radii-layout);--tweet-border:var(--border-layout);--bookmark-padding:calc(var(--padding-layout) + 0.15rem) 0px
          calc(var(--padding-layout) + 0.025rem)
          calc(var(--padding-layout) + 0.275rem);--bookmark-border-radii:var(--border-radii-layout);--bookmark-border:var(--border-layout);--bookmark-image-border-radii:0px
          calc(var(--border-radii-layout) - 1px)
          calc(var(--border-radii-layout) - 1px) 0px;--embed-border-radii:calc(var(--border-radii-layout) - 5px);--image-border-radii:calc(var(--border-radii-layout) - 5px);--title-size:2.5rem;--quote-size:1.2rem;--heading-size:1rem;--primary-font:Inter, Inter-fallback, Helvetica,
          Apple Color Emoji, Segoe UI Emoji, NotoColorEmoji, Noto Color Emoji,
          Segoe UI Symbol, Android Emoji, EmojiSymbols, -apple-system,
          BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Noto Sans,
          sans-serif;--secondary-font:Inter, Inter-fallback, Helvetica,
          Apple Color Emoji, Segoe UI Emoji, NotoColorEmoji, Noto Color Emoji,
          Segoe UI Symbol, Android Emoji, EmojiSymbols, -apple-system,
          BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Noto Sans,
          sans-serif;--text-weight:normal;--heading-weight:600;--heading1-size:calc(var(--heading-size) * 1.875);--heading2-size:calc(var(--heading-size) * 1.5);--heading3-size:calc(var(--heading-size) * 1.25);--heading4-size:calc(var(--heading-size) * 1);--heading5-size:calc(var(--heading-size) * 0.8125);--scrollbar-width:15px;--navbar-height:56px;--navbar-shadow:;--navbar-button-border-radii:50px}html{font-size:16px}body{font-family:var(--secondary-font)}
    </style><style>
      @font-face {
        font-family: "Inter";
        font-style: normal;
        font-display: swap;
        font-weight: 400;
        src: url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-regular.eot"); /* IE9 Compat Modes */
        src: local(""),
          url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-regular.eot?#iefix")
            format("embedded-opentype"),
          /* IE6-IE8 */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-regular.woff2")
            format("woff2"),
          /* Super Modern Browsers */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-regular.woff")
            format("woff"),
          /* Modern Browsers */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-regular.ttf")
            format("truetype"),
          /* Safari, Android, iOS */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-regular.svg#Inter")
            format("svg"); /* Legacy iOS */
      }
    
      @font-face {
        font-family: "Inter";
        font-style: normal;
        font-display: swap;
        font-weight: 500;
        src: url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-500.eot"); /* IE9 Compat Modes */
        src: local(""),
          url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-500.eot?#iefix")
            format("embedded-opentype"),
          /* IE6-IE8 */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-500.woff2")
            format("woff2"),
          /* Super Modern Browsers */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-500.woff")
            format("woff"),
          /* Modern Browsers */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-500.ttf")
            format("truetype"),
          /* Safari, Android, iOS */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-500.svg#Inter")
            format("svg"); /* Legacy iOS */
      }
    
      @font-face {
        font-family: "Inter";
        font-style: normal;
        font-display: swap;
        font-weight: 600;
        src: url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-600.eot"); /* IE9 Compat Modes */
        src: local(""),
          url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-600.eot?#iefix")
            format("embedded-opentype"),
          /* IE6-IE8 */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-600.woff2")
            format("woff2"),
          /* Super Modern Browsers */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-600.woff")
            format("woff"),
          /* Modern Browsers */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-600.ttf")
            format("truetype"),
          /* Safari, Android, iOS */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-600.svg#Inter")
            format("svg"); /* Legacy iOS */
      }
    
      @font-face {
        font-family: "Inter";
        font-style: normal;
        font-display: swap;
        font-weight: 700;
        src: url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-700.eot"); /* IE9 Compat Modes */
        src: local(""),
          url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-700.eot?#iefix")
            format("embedded-opentype"),
          /* IE6-IE8 */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-700.woff2")
            format("woff2"),
          /* Super Modern Browsers */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-700.woff")
            format("woff"),
          /* Modern Browsers */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-700.ttf")
            format("truetype"),
          /* Safari, Android, iOS */
            url("https://assets-v2.super.so/global/fonts/Inter/inter-v12-latin-ext_latin_cyrillic-ext_cyrillic-700.svg#Inter")
            format("svg"); /* Legacy iOS */
      }
    
      @font-face {
        font-family: "Inter-fallback";
        size-adjust: 106.98999999999994%;
        ascent-override: 90%;
        src: local("Arial");
      }
    </style></head><body><div id="__next" data-reactroot=""><div class="jsx-ffddb87d302206e5 error-wrapper error-not-found"><div class="jsx-ffddb87d302206e5"><p class="jsx-ffddb87d302206e5 error-text">This page doesn&#x27;t seem to exist.</p><p class="jsx-ffddb87d302206e5 error-text">Click anywhere to go back.</p></div></div></div><script id="__NEXT_DATA__" type="application/json">{"props":{"pageProps":{}},"page":"/404","query":{},"buildId":"rIxg8tuj6jbVrseXiNqs0","nextExport":true,"autoExport":true,"isFallback":false,"dynamicIds":[1824],"scriptLoader":[]}</script></body></html>